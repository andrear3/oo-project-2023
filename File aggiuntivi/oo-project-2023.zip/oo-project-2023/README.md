# oo-project-2023
Progetto di gruppo con obiettivo la creazione di un applicativo Java dotato di GUI per la gestione di foto geolocalizzate
