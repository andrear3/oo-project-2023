module GUI {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;

}