package Model;

public class User_Tag {
    //Attributi
    private Integer photo_code;
    private String nickname;
    //Costruttori
    public User_Tag(Integer photo_code, String nickname)
    {
        this.photo_code = photo_code;
        this.nickname = nickname;
    }
    public User_Tag(){};
}
